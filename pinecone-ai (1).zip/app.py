from flask import Flask, request, jsonify, send_from_directory
import openai
from flask_cors import CORS

app = Flask(__name__, static_folder="static")
CORS(app)

openai.api_key = "YOUR_OPENAI_API_KEY"

@app.route('/ask', methods=['POST'])
def ask():
    question = request.json.get('message', '')
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role":"user","content":question}]
        )
        return jsonify({"reply": resp.choices[0].message["content"]})
    except Exception as e:
        return jsonify({"reply": f"Error: {e}"})

@app.route('/')
def serve_index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)
